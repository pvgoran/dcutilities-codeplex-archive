# Project Description
DigitallyCreated Utilities are some utilities and extensions that make working in .NET easier. It has classes to help work with LINQ, Entity Framework, ASP.NET MVC, Unity, concurrent programming and error reporting. We value documentation, so everything has a tutorial and XMLdoc.

Currently, the most recent release version of DigitallyCreated Utilities has the following features (categorised by technology):

* **ASP.NET MVC and LINQ**
	* Sorting and paging of data in a table made easy by HtmlHelpers and LINQ extensions (see [tutorial](Basic-Sorter-Tutorial))
* **ASP.NET MVC**
	* HtmlHelpers
		* TempInfoBox - A temporary "action performed" box that displays to the user for 5 seconds then fades out (see [tutorial](TempInfoBox-Tutorial))
		* CollapsibleFieldset - A fieldset that collapses and expands when you click the legend (see [tutorial](CollapsibleFieldset-Tutorial))
		* Gravatar - Renders an {{img}} tag for a [Gravatar](http://www.gravatar.com) (see [tutorial](Gravatar-Tutorial))
		* CheckboxStandard & BoolBinder - Renders a normal checkbox without MVC's normal hidden field (see [tutorial](CheckboxStandard-and-BoolBinder-Tutorial))
		* EncodeAndInsertBrsAndLinks - Great for the display of user input, this will insert {{<br/>}}s for newlines and {{<a>}} tags for URLs and escape all HTML (see [tutorial](EncodeAndInsertBrsAndLinks-Tutorial))
	* IncomingRequestRouteConstraint - Great for supporting old permalink URLs using ASP.NET routing (see [tutorial](IncomingRequestRouteConstraint-Tutorial))
	* Improved JsonResult - Replaces ASP.NET MVC's JsonResult with one that lets you specify JavaScriptConverters (see [tutorial](Improved-JsonResult-Tutorial))
	* Permanently Redirect ActionResults - Redirect users with 301 (Moved Permanently) HTTP status codes (see [tutorial](Permanently-Redirect-ActionResults-Tutorial))
	* Miscellaneous Route Helpers - For example, RouteToCurrentPage (see [tutorial](Route-Helpers-Tutorial))
* **LINQ**
	* MatchUp & Federator LINQ methods - Great for doing diffs on sequences (see [tutorial](MatchUp-and-Federator-LINQ-Methods-Tutorial))
* **Entity Framework**
	* CompiledQueryReplicator - Manage your compiled queries such that you don't accidentally [bake in the wrong MergeOption](http://www.digitallycreated.net/Blog/43/entity-framework-compiled-queries-bake-in-the-mergeoption) and create a difficult to discover bug (see [tutorial](CompiledQueryReplicator-Tutorial))
	* Miscellaneous Entity Framework Utilities - For example, ClearNonScalarProperties and Setting Entity Properties to Modified State (see [tutorial](Miscellaneous-Entity-Framework-Utilities-Tutorial))
* **Error Reporting**
	* Easily wire up some simple classes and have your application email you detailed exception and error object dumps (see [tutorial](Basic-Error-Reporting-Tutorial))
* **Concurrent Programming**
	* Semaphore/FifoSemaphore & Mutex/FifoMutex (see [tutorial](Semaphore_FifoSemaphore-&-Mutex_FifoMutex-Tutorial-and-Implementation-Discussion))
	* ReaderWriterLock (see [tutorial](ReaderWriterLock-Tutorial-and-Implementation-Discussion))
	* LinkedListChannel - A thread-safe queue (see [tutorial](LinkedListChannel-Tutorial-and-Implementation-Discussion))
	* ActiveObject - Easily inherit from ActiveObject to separately thread your class (see [tutorial](Active-Object-Tutorial))
* **Unity & WCF**
	* WCF Client Injection Extension - Easily use dependency injection to transparently inject WCF clients using Unity (see [tutorial](Basic-WCF-Channel-Injection-Tutorial))
* **Miscellaneous Base Class Library Utilities** 
	* SafeUsingBlock and DisposableWrapper - Work with IDisposables in an easier fashion and avoid the bug where using blocks can [silently swallow exceptions](http://www.digitallycreated.net/Blog/51/c%23-using-blocks-can-swallow-exceptions) (see [tutorial](SafeUsingBlock-and-DisposableWrapper-Tutorial))
	* Time Utilities - For example, TimeSpan To Ago String, TzId -> Windows TimeZoneInfo (see [tutorial](Time-Utilities-Tutorial))
	* Miscellaneous Utilities - Collection Add/RemoveAll, Base64StreamReader, AggregateException (see [tutorial](Miscellaneous-Utilities-Tutorial))

# Project Technologies
DC Utilities is written with and is for the following technologies:
* .NET 3.5 SP1, C# 3.0, VS2008
* Entity Framework v1 (.NET 3.5 SP1)
* ASP.NET MVC v1
* Unity Application Block 1.2
* jQuery 1.3.2

# Project Values
* To provide useful utilities and extensions to basic .NET functionality that saves developers' time and makes their code more elegant
* To provide fully XML-documented source code (nothing is more annoying than undocumented code)
* To back up the source code documentation with useful tutorial articles that help developers use this project