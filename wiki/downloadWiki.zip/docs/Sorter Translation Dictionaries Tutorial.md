# Sorter Translation Dictionaries Tutorial
This tutorial explains the use of Sorter Translation Dictionaries, which allow you to shorten the URLs produced by using a Sorter-powered table in an ASP.NET MVC view. This tutorial assumes you are familiar with C#, ASP.NET MVC and the [previous Sorter/Paging tutorial](Basic-Sorter-Tutorial).

In the previous tutorial, we saw URLs being created that look like this:

{code:html}
/Employee/Manage?sort=FirstName!'LastName'Email
{code:html}

That sort parameter is already pretty long! If we had more than three columns in our table, it'd start to get ridiculous. Sorter translation dictionaries provide a way to shorten that down to something more respectable, for example:

{code:html}
/Employee/Manage?sort=F!'L'E
{code:html}

It's quite easy to configure. In your model binder class that you created to bind the Sorter object parameter in your action method, override the TranslationDictionary property in this fashion:

{code:c#}
protected override IDictionary<Expression<Func<Employee, object>>, string> TranslationDictionary
{
    get
    {
        return new Dictionary<Expression<Func<Employee, object>>, string>
                    {
                        { e => e.FirstName, "F" },
                        { e => e.LastName, "L" },
                        { e => e.Email, "E" },
                    };
    }
}
{code:c#}

What you're doing there is returning a dictionary that translates between the sortable properties and their alias name. So we've defined that "F" is the alias for the FirstName property, "L" is the alias for the LastName property, and "E" is the alias for the Email property.

You will also need to modify your override of the CreateNewSorter method so that your new Sorters are told about this translation dictionary (note how the TranslationDictionary property is passed to the constructor of the Sorter):

{code:c#}
protected override Sorter<Employee> CreateNewSorter()
{
    return new Sorter<Employee>(TranslationDictionary)
        .AddProperty(e => e.FirstName, true)
        .AddProperty(e => e.LastName, true)
        .AddProperty(e => e.Email, true);
}
{code:c#}

That's all you have to do. The encoding and decoding of the sort order will now be done via that translation dictionary, and your generated URL will reflect this.