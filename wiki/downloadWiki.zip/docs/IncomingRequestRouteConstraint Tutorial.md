# IncomingRequestRouteConstraint Tutorial
This tutorial aims to illustrate the use of the IncomingRequestRouteConstraint which can be found in the DigitallyCreated.Utilities.Mvc assembly. This tutorial assumes you know C# and ASP.NET MVC.

The purpose of the IncomingRequestRouteConstraint is to allow you to specify on a route that it is only to match a route when it's for an incoming request, not for URL generation (see [RouteDirection](http://msdn.microsoft.com/en-us/library/system.web.routing.routedirection.aspx)). This is great to use when you're providing a route to redirect people from a legacy URL. You don't want the routing engine, when creating URLs via UrlHelper etc, to create a legacy URL, but you _do_ want incoming requests to that legacy URL to work.

Here's an example of its use:
{code:c#}
//In the RegisterRoutes method (or similar) in your global.asax Application class.
routes.MapRoute(
    "OldBlogPhpPermalinkRedirect",
    "Blog/index.php",
    new { controller = "Blog", action = "PermanentlyRedirectToBlog", },
    new { incomingRequestOnly = new IncomingRequestRouteConstraint(), }
    );
{code:c#}