# Making the HtmlHelpers Available for Use Tutorial
This tutorial shows you how to make the HtmlHelpers and other extension methods in the DigitallyCreated.Utilities.Mvc assembly available for use in your Views without doing manual imports. If you find you cannot use the HtmlHelpers because they seem to be missing, it is likely you have forgotten to do this.

To easily use the new HtmlHelpers in your ASP.NET MVC views, add the following to your web.config under the system.web/pages/namespaces tag:

{code:xml}
<add namespace="DigitallyCreated.Utilities.Mvc"/>
{code:xml}

This ensures that your views include that namespace by default, thereby making the new HtmlHelper extension methods available to you without doing manual imports.