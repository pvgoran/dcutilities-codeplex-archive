# Miscellaneous Entity Framework Utilities Tutorial
This tutorial aims to teach you about the existence of and how to use a few small utility methods that can make working with Entity Framework easier. It assumes you already know C# and Entity Framework. All the classes and methods referred to herein belong to the DigitallyCreated.Utilities.Linq library.

## Clear Non-Scalar Properties
The {{EfUtils.ClearNonScalarProperties(EntityObject)}} method allows you to clear all the non-scalar properties on any entity object (any class that derives from EntityObject; all Entity Framework designer entity classes do) with a single method call. Non-scalar properties are defined as:
* EntityCollections: the "many" ends of relationships (think Author.Books)
* The single end of relationships (think Book.Author)

Why would you want to do this? You may have a method somewhat like {{CreateAuthor(Author)}} in your business layer which takes the whole entity object Author. This means that a client (of the business layer) is freely able to set any of the properties on Author, such as Books (an {{EntityCollection<Book>}} navigation property). However, if they do so, they are likely to cause Entity Framework to throw an exception. In the case of adding some Books to Author.Books, Entity Framework will throw an UpdateException when you SaveChanges on your ObjectContext. So generally you will need to perform some manual clearing of objects before adding them to your ObjectContext:

{code:c#}
author.ID = default(int);
author.Books.Clear();
{code:c#}

This is irritating and clutters your code when you're dealing with a number of entities. {{EfUtil.ClearNonScalarProperties(EntityObject)}} will clear all your non-scalar properties in one fell swoop. It is very fast as it will use reflection and System.CodeDom to generate a class at runtime that is able to clear your entity type and then use this class over and over to clear your entity (see [this blog post](http://www.digitallycreated.net/Blog/index.php?id=47) for an implementation discussion and performance report).

{code:c#}
EfUtil.ClearNonScalarProperties(author);
{code:c#}

Not only is this an improvement because it shortens your code but it also aids maintenance because if you add new navigation properties in the future you will not need to go to all your business logic and add in new {{.Clear()}} calls.

## Easy Detach
You may sometimes find yourself in the situation where you need to detach the results of a query from your ObjectContext. You might write code like this:

{code:c#}
List<Author> authors = queryable.ToList();
foreach (Author author in authors)
    context.Detach(author);
{code:c#}

Now you can do all of that in one step:

{code:c#}
IList<Author> authors = EfUtil.Detach(queryable, context);
{code:c#}

## Set Entity Properties to Modified State
In the case where you are taking a detached entity into your business layer for editing (think {{UpdateAuthor(Author)}} in a web app) you will need to set the properties you want Entity Framework to save to the database as "Modified" in Entity Framework's ObjectStateManager, or else when you go {{SaveChanges()}} nothing will be saved! Instead of messing around with the ObjectStateManager directly, you can simply use the {{EfUtil.SetModified}} extension method to do it for you in a type-safe manner:

{code:c#}
author.SetModified(a => a.FirstName, context)
      .SetModified(a => a.LastName, context);
{code:c#}

If you need to set all the properties on your entity as modified, simply use the {{EfUtil.SetAllModified}} extension method:

{code:c#}
author.SetAllModified(context);
{code:c#}
