# Semaphore/FifoSemaphore & Mutex/FifoMutex Tutorial and Implementation Discussion 
This page illustrates the purpose and basic use of a Semaphore and a Mutex, and then discusses the specific implementations used. Semaphore, FifoSemaphore, Mutex and FifoMutex can all be found in the DigitallyCreated.Utilities.Concurrency assembly.

## Tutorials
### Semaphore
A semaphore is a concurrency utility that contains a number of “tokens”. Threads try to acquire (take) and release (put) these tokens into the semaphore. When a semaphore contains no tokens, threads that try to acquire a token must wait until a token is released into the semaphore.

You can acquire tokens by calling these methods:

{code:c#}
bool TryAcquire(int millisecondsTimeout);
bool ForceTryAcquire(int millisecondsTimeout);
void Acquire();
void ForceAcquire();
{code:c#}

The "Try" methods allow you to specify how long you'd like to wait before giving up on acquiring a token. They return false if the timeout expires and true if you've successfully acquired the token. The "Force" methods allow you to acquire a token and be assured that no ThreadInterruptedException will be thrown (good for when you really need to acquire a token without the process being possibly interrupted).

You can release tokens with these methods:

{code:c#}
void Release();
void ReleaseMany(int tokens);
void ForceRelease();
void ForceReleaseMany(int tokens);
{code:c#}

The "Many" methods allow you to release more than one token in one go. The "Force" methods allow you to acquire a token and be assured that no interrupt can occur within that method call.

To construct a Semaphore you need to specify the initial number of tokens it contains in the constructor:

{code:c#}
Semaphore semaphore = new Semaphore(0); //Start with no tokens
{code:c#}

### FifoSemaphore
The FifoSemaphore works exactly like a normal Semaphore but also guarantees that tokens are served out to acquirers in the order that they manage to acquire the internal lock. The usage of a FifoSemaphore is identical to a Semaphore.

### Mutex
A mutex is a concurrency utility that works like a normal C# lock, except that (at least for this implementation) it is not re-entrant. Threads acquire the mutex and until the mutex is released (not necessarily by the same thread that acquired it) threads trying to acquire the mutex have to wait.

This implementation of mutex works as an extension of the semaphore and basically restricts it so that only a maximum of one token can ever be released into it.

When you construct a mutex, you need to specify whether you want it to be preacquired (so the first call to acquire blocks, if release is not called first) or not:

{code:c#}
Mutex mutex = new Mutex(true); //Start preacquired
{code:c#}

### FifoMutex
The FifoMutex works exactly like a normal Mutex but also but also guarantees that tokens are served out to acquirers in the order that they manage to acquire the internal lock. It is inherited from FifoSemaphore like Mutex is inherited from Semaphore.

## Implementation Discussion
Concurrency utilities are hard to implement correctly. These discussions illustrate how these utilities have been implemented and how they work, which should convince you that they're stable. Of course, if you see something I've missed, please do post an issue on the issue tracker.

### Semaphore
This implementation of semaphore allows threads to try to acquire a token and time out if they wait too long. The implementation can also deal with interrupts and ensures that if they were to occur within the semaphore, they would not corrupt internal state. The implementation also allows threads to request the acquiring or releasing of tokens to occur without an interruption (“forced” acquiring/releasing). This implementation does not support thread abortion.

See [here](http://dcutilities.codeplex.com/sourcecontrol/network/Show?projectName=dcutilities&changeSetId=42109#707827) for the code for Semaphore.

{"All the different ways that a thread could acquire a token all call back to the TryAcquire method. The TryAcquire method records the time at which a timeout should occur (timeoutTime). It then acquires the main _Lock, so that it can safely access the _Tokens field and, if necessary, Wait. It then checks to see whether there are any tokens available to acquire. If there is, it takes one and returns. If not, it measures the time it needs to Wait for until timeout, then Waits on the _Lock for that length. Note that if millisecondsTimeout was set to Timeout.Infinite, then the Wait will wait indefinitely (this is what calling the normal Acquire/ForceAcquire does). When the thread wakes from the Wait, it goes back around the loop and tries to take a token. This action could fail if it was woken too early, as could happen if it was pulsed by an interrupted thread that was not pulsed, so if it can’t acquire the token, it measures the amount of time needed to wait until timeout, then if it has run out of time, exits, or if it has more time left, Waits again for that length of time."}

{"If a thread is interrupted while waiting, it pulses the _Lock, just in case it was pulsed and interrupted at the same time. If it did not do this, a pulse could go missing, causing liveness issues where a thread would be waiting, but a token would be available."}

{"All the different ways that a thread could release a token collapse back into a call to the ReleaseMany method. That method is simple: it acquires the _Lock so that it can safely read and change _Tokens. It then adds the number of tokens it needs to _Tokens, then pulses _Lock that many times, just in case there are threads Waiting on _Lock."}

All the Force methods are method variants in which no interrupt can occur. This is done by running the normal method inside a C# finally block, which has the effect of suppressing any interruptions. This does not mean the interrupt is lost; instead, the interrupt will be ignored and when it next gets a chance, it will be thrown (likely in code outside the Force methods). This allows threads to call on methods with the guarantee that they will complete successfully.

### Mutex
This implementation of mutex works as an extension of the semaphore and basically restricts it so that only a maximum of one token can ever be released into it. This means it inherits the ability to deal successfully with interrupts, run methods ignoring interrupts (Forcing), and acquiring with a timeout. It also inherits the inability to deal with thread abortion.

See [here](http://dcutilities.codeplex.com/sourcecontrol/network/Show?projectName=dcutilities&changeSetId=42109#707834) for the code for Mutex.

{"As you can see, this implementation simply overrides the ReleaseMany method of the Semaphore and prevents callers from releasing more than one token, or from releasing at all if a token is already released. Note that to check the value of _Tokens (inherited from Semaphore), it locks against the same object (the inherited _Lock object) as the Semaphore it inherits from."}

### FifoSemaphore
One of the issues with the standard semaphore implementation presented before is that when a thread is waiting for a token to become available during an acquire and is pulsed because a token has become available, it is possible that before it gets a chance to take that token another new thread nips in and takes the token. The woken thread misses out and has to go back to sleep. This situation can cause liveness issues, where some threads starve for tokens while other threads get lots of tokens.

{"The FIFO Semaphore fixes this issue by guaranteeing that tokens are served out to acquirers in the order that they manage to acquire _Lock in the TryAcquire method. This is done by creating a queue of waiting threads, and when tokens become available, waking threads in order off the queue."}

This implementation allows threads to try to acquire a token and time out if they wait too long. The implementation can also deal with interrupts and ensures that if they were to occur within the semaphore, they would not corrupt internal state. The implementation also allows threads to request the acquiring or releasing of tokens to occur without an interruption (“forced” acquiring/releasing). This implementation does not support thread abortion.

See [here](http://dcutilities.codeplex.com/sourcecontrol/network/Show?projectName=dcutilities&changeSetId=42109#707832) for the code for FifoSemaphore.

{"All acquire methods eventually call into TryAcquire, which firstly acquires _Lock. It first checks to see whether there are any tokens, and if there are, it takes one and returns immediately. If not, it creates a Waiter object (Waiter is a private inner class) and enqueues that onto the _WaitQueue. It then releases the _Lock and executes TryWait on the Waiter object. Note that if it didn’t release _Lock and called TryWait on the Waiter, it would continue to hold _Lock as it slept and would prevent any other threads from acquiring _Lock, effectively causing a deadlock."}

{"Inside the Waiter.TryWait method, the waiter acquires its internal _Lock (not the same object as the _Lock used by the main FifoSemaphore class; this is private to the Waiter instance). It checks _Released and if it’s true, it stops waiting and returns. _Released could be true at this point if the Waiter was released (by calling its Release method) before it tries to wait. If it hasn’t been _Released, it waits on _Lock for the timeout specified (which could be Timeout.Infinite). When it wakes it checks to see whether it wakes because it timed out or because it was pulsed. If it was pulsed, it returns. If not, it sets _Released to true (since it’s woken before it has been officially released) and returns. If it wakes because of an interruption, it checks to see whether it was pulsed as well (by checking whether _Released is true, because Release() sets it to true before pulsing). If it was not pulsed, it sets _Released to true (since it was effectively released early) and rethrows the exception. If it was pulsed, it returns normally and schedules the interrupt to happen again at a later time. This means that the interruption is not swallowed silently; it is simply scheduled to occur later."}

{"When Semaphore.ReleaseMany (the method that all Release methods eventually call) is called, it acquires the _Lock so that it can safely touch _WaitQueue and _Tokens fields. Then, for each token to be released, if checks to see whether anyone is waiting, and if they are it dequeues them and releases them. However, it checks the return value and if it is false (as it will be if Waiter.Release is called when _Released is already true) it decrements the loop counter so that the loop will repeat the process again for the current token, since the dequeued Waiter was already released, so it can’t be “given” a token. If no waiters are waiting, then it increments _Tokens."}

{"The Waiter.Release method acquires the Waiter-internal _Lock and checks whether the Waiter has already been released and if so returns false. This will happen if the Waiter has timed out or has been interrupted. Otherwise, it sets _Released to true and pulses _Lock, then returns true."}

All the Force methods are method variants in which no interrupt can occur. This is done by running the normal method inside a C# finally block, which has the effect of suppressing any interruptions. This does not mean the interrupt is lost; instead, the interrupt will be ignored and when it next gets a chance, it will be thrown (likely in code outside the Force methods). This allows threads to call on methods with the guarantee that they will complete successfully.

### FifoMutex
In the same fashion that the normal mutex is an override of the normal semaphore, the FIFO mutex is an override of the FIFO semaphore. Its code is exactly the same as the normal mutex, but instead it inherits from FifoSemaphore instead of Semaphore.

See [here](http://dcutilities.codeplex.com/sourcecontrol/network/Show?projectName=dcutilities&changeSetId=42109#707836) for the code for FifoSemaphore.