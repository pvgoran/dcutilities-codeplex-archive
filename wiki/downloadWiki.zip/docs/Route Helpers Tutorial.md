# Route Helpers Tutorial
This tutorial aims to illustrate the usage of the different utility methods provided in the RouteHelpers class in the DigitallyCreated.Utilities.Mvc assembly. It assumes knowledge of C# and ASP.NET MVC.

## RouteToCurrentPage
Sometimes it's useful to get a RouteValueDictionary containing the necessary route values to generate a URL back to the current page. This includes any URL query parameters (ie {{?param=value}}). The RouteToCurrentPage extension method off of [UrlHelper](http://msdn.microsoft.com/en-us/library/system.web.mvc.urlhelper.aspx) lets you do this. Here is an example of its use in a View:

{code:aspx c#}
<%= Html.RouteLink("Link to current page", Url.RouteToCurrentPage()) %>
{code:aspx c#}

## Fluent Syntax Modification of RouteValueDictionary
Sometimes you need to modify a RouteValueDictionary inline in an expression, especially when working with HtmlHelpers or UrlHelpers. The Include (alias of [Add](http://msdn.microsoft.com/en-us/library/system.web.routing.routevaluedictionary.add.aspx)), Exclude (alias of [Remove](http://msdn.microsoft.com/en-us/library/system.web.routing.routevaluedictionary.remove.aspx)) and Replace (alias for [the indexer](http://msdn.microsoft.com/en-us/library/system.web.routing.routevaluedictionary.item.aspx)) let you do this, as they return the RouteValueDictionary, which allows you use chain up the method calls in the fluent syntax style.
Here's an example of their use:

{code:aspx c#}
<%= Html.RouteLink("Link to current page without sorting", Url.RouteToCurrentPage().Exclude("sort")) %>
{code:aspx c#}

## MapPhysicalToVirtualPath
The MapPhysicalToVirtualPath extension method off of [HttpServerUtilityBase](http://msdn.microsoft.com/en-us/library/system.web.httpserverutilitybase.aspx) (or [HttpServerUtility](http://msdn.microsoft.com/en-us/library/system.web.httpserverutility.aspx)) lets you do the opposite of the [HttpServerUtilityBase.MapPath](http://msdn.microsoft.com/en-us/library/system.web.httpserverutilitybase.mappath.aspx) method, namely get the virtual path for a file whose physical path you have.
Here's an example of its use:

{code:aspx c#}
<a href="<%= ResolveUrl(Context.Server.MapPhysicalToVirtualPath(Model.File.PhysicalPath)) %>">Download file</a>
{code:aspx c#}

## IsCurrentUserAuthorizedForRoute
**WARNING:** This method can be brittle as ASP.NET MVC doesn't really support the finding of an action method outside of an HTTP Request. This method mocks a fake request in order to determine authorization rights. If you get a NotImplementedException, you're probably doing something unexpected and unsupported with these mock request objects. In this case, you can either submit a patch to fix it, or stop using this method.
In addition, as the method effectively simulates a request in order to determine whether the user is authorized for that route, there may be a performance cost. This cost, whether it exists or not, has not been measured or tested and one should keep that in mind when choosing to invest in using this method. If in doubt, I personally suggest you don't use it.

The IsCurrentUserAuthorizedForRoute allows you to specify access rights to various features once and for all as [Authorize](http://msdn.microsoft.com/en-us/library/system.web.mvc.authorizeattribute.aspx) attributes on your Controller and its action methods. In your views, you may be doing something similar to this:

{code:aspx c#}
<% if (User.IsInRole("Administrator")) { %>
    <%= Html.RouteLink("Admin Page", new { controller = "Admin", action = "Index" }) %>
<% } %>
{code:aspx c#}

You would also have the {"[Authorize(Roles="Administrator")](Authorize(Roles=_Administrator_))"} attribute on your action method/controller. However, if you want to change it so that the Developer role had access to the admin pages as well as the Administrator role, you'd need up update not only the attributes on your action method/controller, but also the code in your views. The IsCurrentUserAuthorizedForRoute method lets you just specify your access rights on the controller/action method using attributes, and allows you to use that data from within your view, removing the need for encoding those access rights into your view logic.
Here's how you would use the method:

{code:aspx c#}
<% if (Url.IsCurrentUserAuthorizedForRoute(new { controller = "Admin", action = "Index" }, HttpVerbs.Get)) { %>
    <%= Html.RouteLink("Admin Page", new { controller = "Admin", action = "Index" }) %>
<% } %>
{code:aspx c#}