# DigitallyCreated Utilities Documentation
Welcome to the DigitallyCreated Utilities Documentation wiki. The documentation here aims to get you up to speed with using the various utilities this project contains by providing short tutorials in their use.

The current release version of DigitallyCreated Utilities contains multiple libraries:
* **DigitallyCreated.Utilities.Bcl** - Contains Base Class Library extensions and utilities that are widely applicable.
* **DigitallyCreated.Utilities.Concurrency** - Contains concurrency utilities that you can use when doing concurrent programming.
* **DigitallyCreated.Utilities.ErrorReporting** - Contains classes that enable you to easily set up your application to email you exception and error information.
* **DigitallyCreated.Utilities.Linq** - Contains utilities that can help you when working with LINQ and the Entity Framework.
* **DigitallyCreated.Utilities.Mvc** - Contains HtmlHelpers and other utilities that can help you with ASP.NET MVC projects.
* **DigitallyCreated.Utilities.Unity** - Contains extensions to the Unity dependency injection framework that allow you to inject WCF clients.
The tutorials below are categorised by the libraries that their subject matter is from.

## Tutorials - v1.0.1
These tutorials apply to the release version v1.0.1:
* **Bcl library**
	* [SafeUsingBlock and DisposableWrapper Tutorial](SafeUsingBlock-and-DisposableWrapper-Tutorial)
	* [Time Utilities Tutorial](Time-Utilities-Tutorial)
		* TimeSpan to Ago String (eg "2 minutes ago")
		* Converting between Olson Time Zones (TzIds) and Windows system TimeZoneInfos
	* [Miscellaneous Utilities Tutorial](Miscellaneous-Utilities-Tutorial)
		* Collection AddAll/RemoveAll
		* Case Insensitive String Comparison
		* Base64StreamReader
		* Useful Common Exception Types
			* AggregateException
			* IllegalStateException
			* NotFoundException
* **Concurrency library**
	* [Active Object Tutorial](Active-Object-Tutorial)
	* [Semaphore/FifoSemaphore & Mutex/FifoMutex Tutorial and Implementation Discussion](Semaphore_FifoSemaphore-&-Mutex_FifoMutex-Tutorial-and-Implementation-Discussion)
	* [ReaderWriterLock Tutorial and Implementation Discussion](ReaderWriterLock-Tutorial-and-Implementation-Discussion)
	* [LinkedListChannel Tutorial and Implementation Discussion](LinkedListChannel-Tutorial-and-Implementation-Discussion)
* **ErrorReporting library**
	* [Basic Error Reporting Tutorial](Basic-Error-Reporting-Tutorial)
* **Linq library**
	* [CompiledQueryReplicator Tutorial](CompiledQueryReplicator-Tutorial)
	* [Miscellaneous Entity Framework Utilities Tutorial](Miscellaneous-Entity-Framework-Utilities-Tutorial)
		* Clear Non-Scalar Properties
		* Easy Detach
		* Set Entity Properties to Modified State
	* [MatchUp and Federator LINQ Methods Tutorial](MatchUp-and-Federator-LINQ-Methods-Tutorial)
* **Mvc library**
	* Html Helpers
		* [Making the HtmlHelpers Available for Use Tutorial](Making-the-HtmlHelpers-Available-for-Use-Tutorial)
		* [CheckboxStandard and BoolBinder Tutorial](CheckboxStandard-and-BoolBinder-Tutorial)
		* [TempInfoBox Tutorial](TempInfoBox-Tutorial)
		* [CollapsibleFieldset Tutorial](CollapsibleFieldset-Tutorial)
		* [Gravatar Tutorial](Gravatar-Tutorial)
		* [EncodeAndInsertBrsAndLinks Tutorial](EncodeAndInsertBrsAndLinks-Tutorial)
	* [IncomingRequestRouteConstraint Tutorial](IncomingRequestRouteConstraint-Tutorial)
	* [Improved JsonResult Tutorial](Improved-JsonResult-Tutorial)
	* [Permanently Redirect ActionResults Tutorial](Permanently-Redirect-ActionResults-Tutorial)
	* [Route Helpers Tutorial](Route-Helpers-Tutorial)
		* RouteToCurrentPage
		* Fluent Syntax Modification of RouteValueDictionary
		* MapPhysicalToVirtualPath
		* IsCurrentUserAuthorizedForRoute _(please note warning message in tutorial)_
* **Linq & Mvc libraries together**
	* [Basic Sorter and Paging Tutorial](Basic-Sorter-Tutorial)
	* [Sorter Translation Dictionaries Tutorial](Sorter-Translation-Dictionaries-Tutorial)
	* [PagedSortedViewModel with Auxiliary Data Model Tutorial](PagedSortedViewModel-with-Auxiliary-Data-Model-Tutorial)
* **Unity library**
	* [Basic WCF Client Injection Tutorial](Basic-WCF-Channel-Injection-Tutorial)
	* [WCF Client Injection with Client Certificate from File Tutorial](WCF-Client-Injection-with-Client-Certificate-from-File-Tutorial)

## Tutorials - trunk
These tutorials are for as-of-yet unreleased code that can be found in the repository:
* None