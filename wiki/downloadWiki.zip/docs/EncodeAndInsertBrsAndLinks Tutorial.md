# EncodeAndInsertBrsAndLinks Tutorial
This tutorial illustrates the use of the EncodeAndInsertBrsAndLinks HtmlHelper that can be found in the DigitallyCreated.Utilities.Mvc assembly (in the EyeCandyHtmlHelpers class). It assumes you know C# and ASP.NET MVC.

The EncodeAndInsertBrsAndLinks is great for escaping and displaying user input on a website. It encodes their input (thereby escaping any HTML they use), finds any URLs they use and puts them in unescaped <a> tags, and finds any line breaks and replaces them with <br/>s (works with \r\n as well as \n).

Here's an example of its use in a view:

{code:aspx c#}
//Model.UserInput contains "<strong>Here's a great website!</strong>\r\nhttp://www.digitallycreated.net";
<%= Html.EncodeAndInsertBrsAndLinks(Model.UserInput, true) %>
{code:aspx c#}

The first argument is the string to process, the second is whether or not you want {{rel="nofollow"}} set on all <a> tags created.
This would output the following:

{code:html}
&lt;strong&gt;Here's a great website!&lt;/strong&gt;<br/><a href="http://www.digitallycreated.net" rel="nofollow">http://www.digitallycreated.net</a>
{code:html}