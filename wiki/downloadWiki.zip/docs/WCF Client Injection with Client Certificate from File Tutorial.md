## WCF Client Injection with Client Certificate from File Tutorial
This tutorial aims to teach you how to use the WCF Client Injection extension to [Unity 1.2](http://unity.codeplex.com/) (found in the DigitallyCreated.Utilities.Unity assembly) inject WCF clients that use a client certificate that was loaded from a file. It is assumed you are familiar with C#, WCF, Unity and the [previous tutorial](Basic-WCF-Channel-Injection-Tutorial).

There are some cases where you can't use WCF's configuration XML ({{system.serviceModel}}) to specify a client certificate to use in a binding configuration. The XML binding configuration only lets you specify details about the certificate to be pulled from the local system certificate store. The use case I came across was on ASP.NET shared hosting where you can't install arbitrary certificates in the certificate store, so I needed to load the certificate from a file on disk instead.

Normally to load a certificate from a file on disk and use it in a binding configuration you'd need to write your binding configuration in C# or write the majority of it in XML, then modify it in C# to provide the file-loaded certificate. Obviously, with dependency injection, you have no (or little) control over how the WCF client constructed and configured. 

In the [last tutorial](Basic-WCF-Channel-Injection-Tutorial), the WCF Client Injection extension to Unity injected a WCF client for the IMyService interface. It did this by, behind the scenes, using a [ChannelFactory<T>](http://msdn.microsoft.com/en-us/library/ms576132.aspx) to create a WCF client with specified endpoint configuration. The {{ChannelFactory<T>}} needs to be told up front at construction time the binding configuration to use. The WCF Client Injection extension to Unity abstracts away the construction of a {{ChannelFactory<T>}} behind the {{IChannelFactoryFactory}} interface. The concrete class {{EndpointConfigurationChannelFactoryFactory}} is used by default to create {{ChannelFactory<T>}}s.

But in our case, where we want to customise the endpoint binding configuration with a file-loaded client certificate, the default {{IChannelFactoryFactory}} isn't cutting it. Thankfully, there is a way to choose a different {{IChannelFactoryFactory}} to use. DigitallyCreated.Utilities.Unity contains another {{IChannelFactoryFactory}} that will allow us to use a file-loaded client certificates: the {{ClientCertificateFromFileChannelFactoryFactory}}. (And in the same fashion, if you need to do something that isn't supported by any of the out of the box {{IChannelFactoryFactory}}s, you can create your own and use it).

So, to use the {{ClientCertificateFromFileChannelFactoryFactory}}, we need to customise the {{serviceInterface}} XML element we used in the [last tutorial](Basic-WCF-Channel-Injection-Tutorial):

{code:xml}
<serviceInterface type="MyServices.IMyService, MyServicesAssembly">
    <customChannelFactoryFactory 
        cfgElementType="DigitallyCreated.Utilities.Unity.Configuration.ClientCertificateFromFileChannelFactoryFactoryConfElement, DigitallyCreated.Utilities.Unity"
        endpointConfiguration="MyServiceEndpoint"
        certFilename="~\ServiceClientCertificate.pfx"
        certPassword="" />
</serviceInterface>
{code:xml}

Note that our {{serviceInterface}} element now contains a {{customChannelFactoryFactory}} element. The {{cfgElementType}} attribute specifies the .NET class to use to deserialize the custom configuration element (in this case, for the {{ClientCertificateFromFileChannelFactoryFactory}}, its the hugely named {{ClientCertificateFromFileChannelFactoryFactoryConfElement}}). Notice the endpoint configuration's name has shifted from the {{serviceInterface}} element to the {{customChannelFactoryFactory}}. This is because using the {{endpointConfiguration}} attribute on the {{serviceInterface}} element is just shorthand for telling the extension to use the default {{EndpointConfigurationChannelFactoryFactory}}. The certificate's filename is specified in {{certFilename}} and the password to access it is specified in {{certPassword}}.

And that's it. That custom configuration element class will take care of wiring in the use of the {{ClientCertificateFromFileChannelFactoryFactory}}.